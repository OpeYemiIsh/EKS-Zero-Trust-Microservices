# Terraform Security Guardrails (OPA + tfsec + Checkov)

Reusable **policy-as-code** for AWS/Azure/GCP with OPA/Rego, tfsec, and Checkov. Includes unit tests and GitHub Actions to fail PRs on violations and generate a compliance summary (CIS/NIST mappings).

## Structure
```
policies/
  aws/
    s3-no-public.rego
  azure/
    storage-https-only.rego
  gcp/
    bucket-uniform-access.rego
tests/
  aws/
    s3_public_input.json
ci/workflows/policy-check.yml
docs/mappings.md
```
