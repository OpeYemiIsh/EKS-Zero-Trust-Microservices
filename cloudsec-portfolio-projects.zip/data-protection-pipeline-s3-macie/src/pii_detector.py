import json, re, base64, os
# Placeholder for KMS/tokenization. In production, use boto3 KMS.
PII_PATTERNS = {
  "email": re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}"),
  "phone": re.compile(r"\b\+?1?\d{10,14}\b")
}

def tokenize(value: str) -> str:
  # toy tokenization: DO NOT USE IN PROD
  return "tok_" + base64.urlsafe_b64encode(value.encode()).decode()

def handler(event, context):
  body = event.get('body') or ''
  for name, pat in PII_PATTERNS.items():
    body = pat.sub(lambda m: tokenize(m.group(0)), body)
  return { "statusCode": 200, "body": json.dumps({ "redacted": body }) }
