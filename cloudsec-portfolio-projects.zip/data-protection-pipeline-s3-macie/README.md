# Data Protection Pipeline: S3 + EventBridge + Lambda + Macie + KMS Tokenization

An ingest pipeline that detects PII, **tokenizes** sensitive fields, and stores tokens while keeping original in a secure quarantine. Demonstrates **defense-in-depth** for data at rest and in motion.

## Flow
1. Upload goes to `s3://raw-ingest` (default SSE-KMS).
2. EventBridge triggers `pii-detector` Lambda (regex + placeholder Macie integration).
3. Sensitive fields are tokenized via KMS key; cleartext redacted.
4. Redacted file is written to `s3://clean-zone`; originals to `s3://quarantine` with tighter access.
5. Audit logs to CloudWatch with OCSF-like fields.

## Mermaid
```mermaid
flowchart LR
  U[Uploader] --> S3[(S3 raw-ingest)]
  S3 --> EV[EventBridge]
  EV --> L[Lambda pii-detector]
  L --> KMS[KMS Encrypt/Decrypt]
  L --> CLEAN[(S3 clean-zone)]
  L --> Q[(S3 quarantine)]
  L --> CW[CloudWatch Logs]
```
