# GCP Cloud Run Secure Microservices

Cloud Run services with **Workload Identity Federation** (GitHub OIDC), **Binary Authorization**, **Cloud Armor**, **Secret Manager**, and **VPC-SC** patterns.

## Mermaid
```mermaid
flowchart LR
  GH[GitHub Actions (OIDC)] --> IAM[GCP IAM WIF]
  IAM --> CB[Cloud Build]
  CB --> AR[Artifact Registry]
  AR --> CR1[Cloud Run svc A]
  AR --> CR2[Cloud Run svc B]
  CR1 --> SM[Secret Manager]
  CR1 --> SQL[Cloud SQL (IAM DB Auth)]
```
