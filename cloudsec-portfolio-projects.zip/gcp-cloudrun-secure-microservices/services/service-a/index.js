const express = require('express');
const app = express();
app.get('/healthz', (req,res)=>res.json({status:'ok'}));
app.get('/secure', (req,res)=>{
  if ((req.headers['x-forwarded-proto']||'').toLowerCase() !== 'https') {
    return res.status(400).send('TLS required');
  }
  res.json({ ok: true, at: new Date().toISOString() });
});
app.listen(process.env.PORT||8080);
