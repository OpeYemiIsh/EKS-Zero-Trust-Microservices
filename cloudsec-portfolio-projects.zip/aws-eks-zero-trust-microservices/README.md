# AWS EKS Zero-Trust Microservices

Portfolio-ready project showcasing a production-style microservices stack on Amazon EKS with **mTLS (Istio)**, **policy-as-code (OPA/Gatekeeper)**, **supply-chain security (Cosign + SBOM)**, and **GitHub OIDC** for secretless deployments.

## Highlights
- EKS with managed node groups and IRSA
- Istio service mesh enforcing mTLS, PeerAuthentication STRICT
- OPA Gatekeeper policies for guardrails (privileged pods, namespaces, labels)
- Sigstore Cosign image signing + SBOM generation (Syft) in CI
- Trivy/Grype container scanning; tfsec/Checkov IaC scanning
- Least-privilege IAM roles for workloads via IRSA
- Centralized logs via CloudWatch and OpenTelemetry
- Canary releases with Istio + progressive delivery

## Architecture (Mermaid)
```mermaid
flowchart LR
  A[Github Actions (OIDC)] -->|assume role| I(AWS IAM)
  I --> T(Terraform applies EKS/IRSA)
  subgraph Cluster[EKS + Istio]
    O1[orders svc]:::svc --> Istio[(mTLS)]
    P1[payments svc]:::svc --> Istio
    G[Gatekeeper/OPA]:::ctrl -->|admission| O1
    G --> P1
  end
  R[(ECR)] --> Cluster
classDef svc fill:#e6f7ff,stroke:#0366d6,stroke-width:1px;
classDef ctrl fill:#fff7e6,stroke:#d46b08,stroke-width:1px;
```
## Repo Structure
```
infra/
  terraform/
    eks/
    iam-irsa/
k8s/
  base/
    namespace.yaml
    networkpolicies.yaml
  istio/
    peer-auth.yaml
    destinationrule.yaml
  gatekeeper/
    templates/
    constraints/
services/
  orders/
    app/
      main.py
    Dockerfile
    k8s/ (deployment, service, vs)
  payments/
    app/
      main.py
    Dockerfile
    k8s/
policy/
  opa/
    deny-privileged.rego
  kyverno/
ci/
  workflows/
    build-sign-deploy.yml
docs/
  threat-model.md
  runbook.md
```

## Getting Started
1. Configure **GitHub OIDC** to AWS and create a deploy role (see `infra/terraform/iam-irsa/`).
2. `terraform apply` EKS + IRSA.
3. `kubectl apply -k k8s/base` then `k8s/istio` and `k8s/gatekeeper`.
4. Push a change; GitHub Actions will build, scan, sign, and deploy images.

---
*What this demonstrates:* zero-trust service-to-service auth, supply-chain hardening, and admission guardrails—exactly what a Cloud Security Solution Architect designs.
