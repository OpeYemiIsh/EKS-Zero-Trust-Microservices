package k8srequiredlabels

violation[{"msg": msg}] {
  input.review.kind.kind == "Namespace"
  not input.review.object.metadata.labels["owner"]
  msg := "namespace must have an 'owner' label"
}
