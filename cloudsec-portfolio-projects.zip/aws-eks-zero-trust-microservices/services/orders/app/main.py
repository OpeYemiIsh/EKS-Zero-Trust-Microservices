from fastapi import FastAPI, Request, HTTPException
import os

app = FastAPI()

# Simple token check to simulate zero-trust + mTLS (Istio handles mTLS)
SERVICE_TOKEN = os.getenv("SERVICE_TOKEN", "change-me")

@app.get("/healthz")
def health():
    return {"status": "ok"}

@app.get("/orders")
def list_orders(request: Request):
    token = request.headers.get("x-service-token")
    if token != SERVICE_TOKEN:
        raise HTTPException(status_code=401, detail="unauthorized")
    return [{"id": "ord_001", "amount": 95.50, "currency": "USD"}]
