module.exports = async function (context, req) {
  const auth = req.headers['authorization'] || '';
  if (!auth.toLowerCase().startsWith('bearer ')) {
    context.res = { status: 401, body: 'Unauthorized' };
    return;
  }
  // JWT is validated at APIM; here we trust X-Client-Principal or claims injected header
  context.log('Claims:', req.headers['x-jwt-claims'] || '');
  context.res = { status: 200, body: { status: 'ok', ts: new Date().toISOString() } };
}
