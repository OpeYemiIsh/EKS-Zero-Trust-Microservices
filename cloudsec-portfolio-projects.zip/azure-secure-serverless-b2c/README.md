# Azure Secure Serverless (Functions + API Management + Azure AD B2C)

Event-driven APIs using **Azure Functions**, fronted by **API Management** with **JWT validation**, **rate limiting**, **private endpoints**, **Managed Identity**, and **Key Vault** secrets.

## Security Controls
- APIM inbound policies to validate JWT (`aud`, `iss`, `exp`), and apply throttling
- Private endpoints for Functions and CosmosDB; no public outbound
- Managed Identity for Functions to access Key Vault (no secrets in code)
- Defender for Cloud recommendations baselined
- GitHub → Azure OIDC for secretless deployment

## Mermaid
```mermaid
flowchart LR
  U[Client] --> APIM[API Management (JWT + throttle)]
  APIM --> F[Azure Functions]
  F --> KV[Key Vault]
  F --> COS[Cosmos DB (private link)]
  GH[GitHub OIDC] --> AZ[Azure IAM (federated cred)]
```
