# AWS Serverless Zero-Trust API

API Gateway + Lambda + DynamoDB + Cognito + WAF + KMS with **JWT authorizer**, **least privilege IAM**, **KMS envelope encryption**, **Secrets Manager**, and **audit-ready logging**.

## Architecture (Mermaid)
```mermaid
sequenceDiagram
  participant User
  participant APIGW as API Gateway (WAF + JWT Authorizer)
  participant L as Lambda (orders)
  participant D as DynamoDB (KMS)
  participant C as Cognito
  User->>C: Authenticate (OIDC/OAuth2)
  C-->>User: ID/Access Token (JWT)
  User->>APIGW: GET /orders (Bearer JWT)
  APIGW->>L: Invoke (IAM + policy)
  L->>D: Query (KMS-encrypted)
  L-->>APIGW: Response (structured logs)
  APIGW-->>User: 200 OK
```

## Security Controls
- JWT validation (kid/alg check, exp/nbf/aud/iss)
- Input validation + OWASP ASVS logging & error handling
- WAF managed rules + custom IP sets
- IAM least privilege, no wildcards; separated reader/writer roles
- KMS CMK for DynamoDB + envelope encryption per record
- CloudWatch structured logs (JSON) and metrics filters for 4xx/5xx spikes

## Quickstart
- `infra/terraform` provisions all AWS resources (variables are placeholders).
- Deploy via GitHub Actions OIDC (see `ci/workflows/deploy.yml`).
