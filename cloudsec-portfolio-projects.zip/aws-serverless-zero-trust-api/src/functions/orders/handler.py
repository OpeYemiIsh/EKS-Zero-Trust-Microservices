import json, os, boto3, base64
from datetime import datetime

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ.get("ORDERS_TABLE","orders"))

def handler(event, context):
    # basic input validation
    q = event.get("queryStringParameters") or {}
    limit = int(q.get("limit", "10"))
    if limit <= 0 or limit > 100:
        return {"statusCode": 400, "body": "invalid limit"}
    items = [{"id":"ord_001","amount":9550,"currency":"USD","created":datetime.utcnow().isoformat()}]
    return {"statusCode": 200, "headers": {"Content-Type": "application/json"}, "body": json.dumps(items)}
