import json, os, time, base64, hashlib, hmac, requests, jwt
from jwt import PyJWKClient

ISSUER = os.environ.get("JWT_ISSUER")
AUDIENCE = os.environ.get("JWT_AUD")
JWKS_URL = os.environ.get("JWKS_URL")

def handler(event, context):
    auth = event.get("headers", {}).get("authorization") or event.get("headers", {}).get("Authorization")
    if not auth or not auth.lower().startswith("bearer "):
        return {"statusCode": 401, "body": "Unauthorized"}
    token = auth.split(" ", 1)[1].strip()
    jwks_client = PyJWKClient(JWKS_URL)
    signing_key = jwks_client.get_signing_key_from_jwt(token).key
    decoded = jwt.decode(token, signing_key, algorithms=["RS256"], audience=AUDIENCE, issuer=ISSUER)
    return {"isAuthorized": True, "context": {"sub": decoded.get("sub"), "scope": decoded.get("scope","") }}
